import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeAnimation;
  late Animation<double> _slideAnimation;

  final TextStyle _headerStyle = GoogleFonts.tajawal(
    fontSize: 32,
    fontWeight: FontWeight.bold,
    color: Color(0xFF1C3D5A),
  );

  final TextStyle _subHeaderStyle = GoogleFonts.tajawal(
    fontSize: 24,
    fontWeight: FontWeight.w600,
    color: Color(0xFF1C3D5A),
  );

  final TextStyle _bodyStyle = GoogleFonts.tajawal(
    fontSize: 16,
    color: Color(0xFF1C3D5A).withOpacity(0.8),
  );

  final TextStyle _buttonStyle = GoogleFonts.tajawal(
    fontSize: 18,
    fontWeight: FontWeight.w600,
    color: Colors.white,
  );

  final TextStyle _linkStyle = GoogleFonts.tajawal(
    fontSize: 14,
    color: Color(0xFF1C3D5A),
    fontWeight: FontWeight.w500,
  );

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(
          parent: _controller,
          curve: const Interval(0.0, 0.5, curve: Curves.easeIn),
        ));

    _slideAnimation = Tween<double>(begin: 50.0, end: 0.0).animate(
        CurvedAnimation(
          parent: _controller,
          curve: const Interval(0.3, 1.0, curve: Curves.easeOut),
        ));

    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5F5F5),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF1C3D5A)),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 40),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
          AnimatedBuilder(
          animation: _fadeAnimation,
          builder: (context, child) {
            return Opacity(
              opacity: _fadeAnimation.value,
              child: Transform.translate(
                offset: Offset(0, _slideAnimation.value),
                child: child,
              ),
            );
          },
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(Icons.shopping_cart, color: Color(0xFFFFA726), size: 32),
                  SizedBox(width: 8),
                  Text("تاجرلي", style: _headerStyle),
                ],
              ),
              const SizedBox(height: 8),
              Text("أهلاً بعودتك!", style: _subHeaderStyle),
              const SizedBox(height: 8),
              Text("منصة تأجير المنتجات الأولى في مصر", style: _bodyStyle),
            ],
          ),
        ),

        const SizedBox(height: 50),

        // Email Field
        AnimatedBuilder(
          animation: _fadeAnimation,
          builder: (context, child) {
            return Opacity(
              opacity: _fadeAnimation.value,
              child: Transform.translate(
                offset: Offset(0, _slideAnimation.value),
                child: child,
              ),
            );
          },
          child: _buildTextField("البريد الإلكتروني"),
        ),

        // Password Field
        AnimatedBuilder(
          animation: _fadeAnimation,
          builder: (context, child) {
            return Opacity(
              opacity: _fadeAnimation.value,
              child: Transform.translate(
                offset: Offset(0, _slideAnimation.value),
                child: child,
              ),
            );
          },
          child: _buildTextField("كلمة المرور", isPassword: true),
        ),

        const SizedBox(height: 16),

        // Forgot Password
        AnimatedBuilder(
          animation: _fadeAnimation,
          builder: (context, child) {
            return Opacity(
              opacity: _fadeAnimation.value,
              child: Transform.translate(
                offset: Offset(0, _slideAnimation.value),
                child: child,
              ),
            );
          },
          child: Align(
            alignment: Alignment.centerLeft,
            child: TextButton(
              onPressed: () {},
              child: Text("نسيت كلمة المرور؟", style: _linkStyle),
            ),
          ),
        ),

        const SizedBox(height: 30),

        // Login Button
        AnimatedBuilder(
          animation: _fadeAnimation,
          builder: (context, child) {
            return Opacity(
              opacity: _fadeAnimation.value,
              child: Transform.translate(
                offset: Offset(0, _slideAnimation.value),
                child: child,
              ),
            );
          },
          child: ElevatedButton(
            onPressed: () {},
            style: ElevatedButton.styleFrom(
              backgroundColor: Color(0xFF66BB6A),
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 16),
              textStyle: _buttonStyle,
              minimumSize: const Size.fromHeight(50),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              elevation: 3,
              shadowColor: Color(0xFF66BB6A).withOpacity(0.3),
            ),
            child: const Text("تسجيل الدخول"),
          ),
        ),

        const SizedBox(height: 30),

        // Or continue with
        Column(
          children: [
            AnimatedBuilder(
              animation: _fadeAnimation,
              builder: (context, child) {
                return Opacity(
                  opacity: _fadeAnimation.value,
                  child: Transform.translate(
                    offset: Offset(0, _slideAnimation.value),
                    child: child,
                  ),
                );
              },
              child: Center(
                child: Text(
                  "أو سجل الدخول باستخدام",
                  style: _bodyStyle.copyWith(
                    color: Color(0xFF1C3D5A).withOpacity(0.7),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 30),
          ],
        ),

        Column(
          children: [
            AnimatedBuilder(
                animation: _fadeAnimation,
                builder: (context, child) {
                  return Opacity(
                    opacity: _fadeAnimation.value,
                    child: Transform.translate(
                      offset: Offset(0, _slideAnimation.value),
                      child: child,
                    ),
                  );
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _buildSocialButton(Icons.g_mobiledata, const Color(0xFFDB4437)),
                    const SizedBox(width: 20),
                    _buildSocialButton(Icons.facebook, const Color(0xFF4267B2)),
                    const SizedBox(width: 20),
                    _buildSocialButton(Icons.apple, Colors.black),
                  ],
                ),
              ),
          ],
        ),

          const SizedBox(height: 20),

          // Sign up link
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text("ليس لديك حساب؟", style: _bodyStyle),
              TextButton(
                onPressed: () {},
                child: Text("سجل الآن", style: _linkStyle.copyWith(fontWeight: FontWeight.bold)),
              ),
            ],
          )
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(String label, {bool isPassword = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: TextField(
        obscureText: isPassword,
        style: _bodyStyle.copyWith(color: Color(0xFF1C3D5A)),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: _bodyStyle.copyWith(color: Color(0xFF1C3D5A).withOpacity(0.6)),
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Color(0xFF1C3D5A).withOpacity(0.2)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(
              color: Color(0xFF1C3D5A),
              width: 1.5,
            ),
          ),
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 18,
          ),
        ),
      ),
    );
  }

  Widget _buildSocialButton(IconData icon, Color color) {
    return Container(
      width: 50,
      height: 50,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Color(0xFF1C3D5A).withOpacity(0.1),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 1,
            blurRadius: 5,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Icon(icon, color: color, size: 28),
    );
  }
}