import 'package:flutter/material.dart';
import 'package:flutter/animation.dart';

class AboutUsPage extends StatefulWidget {
  const AboutUsPage({super.key});

  @override
  State<AboutUsPage> createState() => _AboutUsPageState();
}

class _AboutUsPageState extends State<AboutUsPage> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _opacityAnimation;
  late Animation<double> _translateAnimation;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );

    _opacityAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(
          parent: _controller,
          curve: const Interval(0.0, 0.5, curve: Curves.easeIn),
        ));

    _translateAnimation = Tween<double>(begin: 50.0, end: 0.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.3, 1.0, curve: Curves.easeOut),
      ),
    );

    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Widget _buildAnimatedSection(Widget child, {double delay = 0.0}) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return Opacity(
          opacity: _opacityAnimation.value,
          child: Transform.translate(
            offset: Offset(0, _translateAnimation.value * (1 - delay)),
            child: child,
          ),
        );
      },
      child: child,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      appBar: AppBar(
        title: const Text('من نحن', style: TextStyle(color: Colors.white)),
        centerTitle: true,
        backgroundColor: const Color(0xFF1C3D5A),
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildAnimatedSection(
              _buildHeaderSection(),
              delay: 0.1,
            ),
            const SizedBox(height: 30),
            _buildAnimatedSection(
              _buildInfoCard(
                icon: Icons.group,
                title: 'من نحن',
                content: 'نحن فريق من المحترفين المتفانين الذين يجمعهم شغف تقديم حلول إيجارية مبتكرة. تأسست منصتنا برؤية واضحة لتبسيط عملية التأجير وجعلها أكثر كفاءة وموثوقية.',
              ),
              delay: 0.2,
            ),
            const SizedBox(height: 20),
            _buildAnimatedSection(
              _buildInfoCard(
                icon: Icons.leaderboard,
                title: 'قيادة رائدة',
                content: 'نقود من الأمام من خلال الابتكار المستمر وتبني أحدث التقنيات. نؤمن بأن القيادة الحقيقية تعني تمكين عملائنا وشركائنا لتحقيق أهدافهم.',
                color: const Color(0xFF66BB6A),
              ),
              delay: 0.3,
            ),
            const SizedBox(height: 20),
            _buildAnimatedSection(
              _buildInfoCard(
                icon: Icons.star,
                title: 'ما نتميز به',
                content: 'نقدم تجربة مستخدم فريدة مع واجهة بسيطة وسهلة الاستخدام. نضمن الأمان والشفافية في كل معاملة، مع دعم فني متاح على مدار الساعة.',
                color: const Color(0xFFFFA726),
              ),
              delay: 0.4,
            ),
            const SizedBox(height: 20),
            _buildAnimatedSection(
              _buildStrategySection(),
              delay: 0.5,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeaderSection() {
    return Column(
      children: [
        Container(
          height: 150,
          decoration: BoxDecoration(
            color: const Color(0xFF1C3D5A).withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Icon(Icons.business, size: 80, color: Color(0xFF1C3D5A)),
        ),
        const SizedBox(height: 20),
        const Text(
          'إيجارك - منصة التأجير الرائدة',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Color(0xFF1C3D5A),
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _buildInfoCard({
    required IconData icon,
    required String title,
    required String content,
    Color color = const Color(0xFF1C3D5A),
  }) {
    return Card(
      elevation: 6,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.2),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(icon, color: color, size: 24),
                ),
                const SizedBox(width: 15),
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: color,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 15),
            Text(
              content,
              style: TextStyle(
                fontSize: 16,
                height: 1.5,
                color: Colors.grey.shade700,
              ),
              textAlign: TextAlign.start,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStrategySection() {
    return Card(
      elevation: 6,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1C3D5A).withOpacity(0.2),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.auto_graph, color: Color(0xFF1C3D5A), size: 24),
                ),
                const SizedBox(width: 15),
                const Text(
                  'استراتيجيتنا',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF1C3D5A),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 15),
            _buildStrategyItem('التركيز على العميل', Icons.person),
            _buildStrategyItem('الابتكار المستمر', Icons.lightbulb),
            _buildStrategyItem('الجودة والموثوقية', Icons.verified),
            _buildStrategyItem('النمو المستدام', Icons.trending_up),
          ],
        ),
      ),
    );
  }

  Widget _buildStrategyItem(String text, IconData icon) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFF1C3D5A), size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: TextStyle(fontSize: 16, color: Colors.grey.shade700),
            ),
          ),
        ],
      ),
    );
  }
}