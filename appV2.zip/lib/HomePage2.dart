import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_swiper_view/flutter_swiper_view.dart';

class HomePage2 extends StatefulWidget {
  const HomePage2({Key? key}) : super(key: key);

  @override
  State<HomePage2> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage2> {
  // تعريف أنماط الخطوط المخصصة
  final TextStyle _headerStyle = GoogleFonts.tajawal(
    fontSize: 32,
    fontWeight: FontWeight.bold,
    color: const Color(0xFF1C3D5A),
  );

  final TextStyle _subHeaderStyle = GoogleFonts.tajawal(
    fontSize: 24,
    fontWeight: FontWeight.w600,
    color: const Color(0xFF1C3D5A),
  );

  final TextStyle _bodyStyle = GoogleFonts.tajawal(
    fontSize: 16,
    color: const Color(0xFF1C3D5A).withOpacity(0.8),
  );

  final TextStyle _buttonStyle = GoogleFonts.tajawal(
    fontSize: 18,
    fontWeight: FontWeight.w600,
    color: Colors.white,
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      body: CustomScrollView(
        slivers: [
          // AppBar مخصص
          SliverAppBar(
            backgroundColor: Colors.white,
            floating: true,
            pinned: true,
            expandedHeight: 100,
            flexibleSpace: FlexibleSpaceBar(
              title: Text('إيجارك', style: _headerStyle.copyWith(fontSize: 24)),
              background: Container(color: Colors.white),
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.search),
                onPressed: () {},
              ),
              IconButton(
                icon: const Icon(Icons.person),
                onPressed: () {},
              ),
              IconButton(
                icon: const Icon(Icons.favorite_border),
                onPressed: () {},
              ),
              IconButton(
                icon: const Icon(Icons.shopping_cart),
                onPressed: () {},
              ),
            ],
          ),

          // محتوى الصفحة
          SliverList(
            delegate: SliverChildListDelegate([
              // قسم Hero Swiper
              SizedBox(
                height: 500,
                child: Swiper(
                  itemBuilder: (BuildContext context, int index) {
                    return _buildHeroSlide(index);
                  },
                  itemCount: 3,
                  pagination: const SwiperPagination(),
                  control: const SwiperControl(),
                  autoplay: true,
                  viewportFraction: 1.0,
                  scale: 0.9,
                ),
              ),

              // قسم الفئات
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('فئات التأجير', style: _subHeaderStyle),
                    const SizedBox(height: 8),
                    Text('اختر من بين مجموعة واسعة من العناصر المتاحة للتأجير', style: _bodyStyle),
                    const SizedBox(height: 16),
                    GridView.count(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      crossAxisCount: 2,
                      childAspectRatio: 0.8,
                      children: [
                        _buildCategoryCard('السيارات', 'assets/car.png'),
                        _buildCategoryCard('الشقق والسكن', 'assets/house.jpg'),
                        _buildCategoryCard('الملابس', 'assets/dress.jpg'),
                        _buildCategoryCard('الأدوات والمعدات', 'assets/camera.png'),
                      ],
                    ),
                  ],
                ),
              ),

              // قسم كيف يعمل
              Container(
                color: const Color(0xFFF0F0F0),
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('كيف يعمل إيجارك؟', style: _subHeaderStyle),
                    const SizedBox(height: 8),
                    Text('3 خطوات بسيطة لتأجير ما تحتاجه', style: _bodyStyle),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        _buildStepCard(1, 'ابحث واحجز', Icons.search),
                        _buildStepCard(2, 'اكمل الدفع', Icons.credit_card),
                        _buildStepCard(3, 'استلم واستمتع', Icons.check_circle),
                      ],
                    ),
                  ],
                ),
              ),

              // قسم Call to Action
              Container(
                padding: const EdgeInsets.all(32.0),
                child: Column(
                  children: [
                    Text('هل لديك شيء لتؤجره؟', style: _subHeaderStyle),
                    const SizedBox(height: 8),
                    Text('انضم إلى منصة إيجارك وابدأ بكسب المال من الأشياء التي لا تستخدمها',
                        style: _bodyStyle, textAlign: TextAlign.center),
                    const SizedBox(height: 24),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        ElevatedButton(
                          onPressed: () {
                            // Navigate to sign up as renter/owner
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF1C3D5A),
                            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                          ),
                          child: Text('التسجيل كمستأجر او مؤجر', style: _buttonStyle),
                        ),
                        const SizedBox(width: 16),
                        OutlinedButton(
                          onPressed: () {
                            // Navigate to sign up as company
                          },
                          style: OutlinedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                            side: const BorderSide(color: Color(0xFF1C3D5A)),
                          ),
                          child: Text('التسجيل كشركه', style: _buttonStyle.copyWith(color: const Color(0xFF1C3D5A))),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              // Footer
              Container(
                color: const Color(0xFF1C3D5A),
                padding: const EdgeInsets.all(24.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('إيجارك', style: _headerStyle.copyWith(color: Colors.white)),
                    const SizedBox(height: 16),
                    Text('منصة إيجارك هي الحل الأمثل لتأجير كل ما تحتاجه أو كسب المال من تأجير ممتلكاتك. نوفر تجربة آمنة وسهلة للجميع.',
                        style: _bodyStyle.copyWith(color: Colors.white70)),
                    const SizedBox(height: 24),
                    Row(
                      children: [
                        IconButton(icon: const Icon(Icons.facebook, color: Colors.white), onPressed: () {}),
                      //   IconButton(icon: const Icon(Icons.twitter, color: Colors.white), onPressed: () {}),
                      //   IconButton(icon: const Icon(Icons.instagram, color: Colors.white), onPressed: () {}),
                      ],
                    ),
                    const SizedBox(height: 24),
                    const Divider(color: Colors.white54),
                    const SizedBox(height: 16),
                    Text('© حقوق النشر إيجارك. جميع الحقوق محفوظة.',
                        style: _bodyStyle.copyWith(color: Colors.white70)),
                  ],
                ),
              ),
            ]),
          ),
        ],
      ),
    );
  }

  Widget _buildHeroSlide(int index) {
    final List<Map<String, dynamic>> slides = [
      {
        'title': 'اكتشف عالمًا من الخيارات للتأجير',
        'description': 'منصة إيجارك توفر لك كل ما تحتاجه من سيارات، شقق، ملابس وأدوات بتجربة سهلة وآمنة وبأسعار تنافسية',
        'image': 'assets/car.png',
        'features': [
          {'icon': Icons.security, 'title': 'ضمان آمن', 'desc': 'حماية كاملة لجميع عمليات التأجير'},
          {'icon': Icons.attach_money, 'title': 'أسعار تنافسية', 'desc': 'أفضل الأسعار في السوق'},
        ]
      },
      {
        'title': 'استأجر شقتك بسهولة وأمان',
        'description': 'نوفر لك شقق مجهزة للإيجار الشهري أو اليومي بأفضل الأسعار',
        'image': 'assets/house.jpg',
        'features': [
          {'icon': Icons.home, 'title': 'خيارات متنوعة', 'desc': 'شقق بمواصفات مختلفة تناسب جميع الاحتياجات'},
          {'icon': Icons.key, 'title': 'تأجير مباشر', 'desc': 'بدون وسيط وبأسعار مناسبة'},
        ]
      },
      {
        'title': 'احجز ملابسك للمناسبات بكل سهولة',
        'description': 'ملابس فاخرة ومتنوعة للإيجار اليومي أو الأسبوعي',
        'image': 'assets/dress.jpg',
        'features': [
          {'icon': Icons.shopping_bag, 'title': 'تصاميم مميزة', 'desc': 'أحدث صيحات الموضة من مصممين معروفين'},
          {'icon': Icons.local_shipping, 'title': 'توصيل سريع', 'desc': 'استلم طلبك في المكان والوقت المناسبين'},
        ]
      },
    ];

    final slide = slides[index];

    return Container(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          Expanded(
            child: Image.asset(slide['image'], fit: BoxFit.contain),
          ),
          const SizedBox(height: 16),
          Text(slide['title'], style: _subHeaderStyle.copyWith(fontSize: 28)),
          const SizedBox(height: 8),
          Text(slide['description'],
            style: _bodyStyle.copyWith(fontSize: 18),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16),
          Column(
            children: [
              for (var feature in slide['features'])
                ListTile(
                  leading: Icon(feature['icon'], color: const Color(0xFF1C3D5A)),
                  title: Text(feature['title'], style: _bodyStyle.copyWith(fontWeight: FontWeight.bold)),
                  subtitle: Text(feature['desc'], style: _bodyStyle),
                ),
            ],
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: () {},
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF1C3D5A),
              padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
            ),
            child: Text('اعرف المزيد', style: _buttonStyle),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryCard(String title, String image) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          Expanded(
            child: ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
              child: Image.asset(image, fit: BoxFit.cover, width: double.infinity),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(title, style: _subHeaderStyle.copyWith(fontSize: 18)),
          ),
          Padding(
            padding: const EdgeInsets.only(bottom: 8.0),
            child: OutlinedButton(
              onPressed: () {},
              child: Text('استعرض العروض', style: _bodyStyle),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStepCard(int number, String title, IconData icon) {
    return Expanded(
      child: Card(
        elevation: 2,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              CircleAvatar(
                backgroundColor: const Color(0xFF1C3D5A),
                child: Text(number.toString(), style: const TextStyle(color: Colors.white)),
              ),
              const SizedBox(height: 8),
              Icon(icon, size: 40, color: const Color(0xFF1C3D5A)),
              const SizedBox(height: 8),
              Text(title, style: _subHeaderStyle.copyWith(fontSize: 18)),
            ],
          ),
        ),
      ),
    );
  }
}