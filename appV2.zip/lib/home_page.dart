import 'package:flutter/material.dart';

import 'CategoriesPage.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _currentIndex = 0;
  bool userIsLoggedIn = false;
  String? userName;

  final TextStyle _subHeaderStyle = TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.bold,
    color: Color(0xFF1C3D5A),
  );

  final TextStyle _bodyStyle = TextStyle(
    fontSize: 14,
    color: Colors.grey[700],
  );

  final TextStyle _buttonStyle = TextStyle(
    fontSize: 14,
    fontWeight: FontWeight.bold,
    color: Colors.white,
  );

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.shopping_cart, color: Color(0xFFFFA726)),
              SizedBox(width: 8),
              Text('إيجارك', style: TextStyle(color: Colors.white)),
            ],
          ),
          backgroundColor: Color(0xFF1C3D5A),
          actions: [
            IconButton(
              icon: Icon(Icons.person, color: Colors.white),
              onPressed: () {
                if (!userIsLoggedIn) {
                  Navigator.pushNamed(context, '/login');
                } else {
                  // Open profile page
                }
              },
            ),
          ],
        ),
        body: SingleChildScrollView(
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(height: 20),
            Text(
              'إيجارك',
              style: TextStyle(
                fontSize: 36,
                fontWeight: FontWeight.bold,
                color: Color(0xFF1C3D5A),
              ),
            ),
            SizedBox(height: 20),
                    Container(
                      padding: EdgeInsets.all(32.0),
                      child: Column(
                        children: [
                          Text('هل لديك شيء لتؤجره؟', style: _subHeaderStyle),
                          SizedBox(height: 8),
                          Text(
                            'انضم إلى منصة إيجارك وابدأ بكسب المال من الأشياء التي لا تستخدمها',
                            style: _bodyStyle,
                            textAlign: TextAlign.center,
                          ),
                          SizedBox(height: 24),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              ElevatedButton(
                                onPressed: () {
                                  if (!userIsLoggedIn) {
                                    Navigator.pushNamed(context, '/formI');
                                  } else {
                                    // Navigate to renter/rentee interface
                                  }
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Color(0xFF1C3D5A),
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 12),
                                ),
                                child: Text(
                                  'التسجيل كمستأجر او مؤجر',
                                  style: _buttonStyle,
                                ),
                              ),
                              SizedBox(width: 16),
                              OutlinedButton(
                                onPressed: () {
                                  if (!userIsLoggedIn) {
                                    Navigator.pushNamed(context, '/formC');
                                  } else {
                                    // Navigate to companies interface
                                  }
                                },
                                style: OutlinedButton.styleFrom(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 24, vertical: 12),
                                  side: BorderSide(color: Color(0xFF1C3D5A)),
                                ),
                                child: Text(
                                  'التسجيل كشركه',
                                  style: _buttonStyle.copyWith(
                                      color: Color(0xFF1C3D5A)),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 40),
                      child: Text(
                        'منصة إيجارك هي الحل الأمثل لتأجير واستئجار مختلف المنتجات والعقارات بكل سهولة وأمان. نوفر لك تجربة سلسة وآمنة لإتمام عمليات التأجير.',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.grey[700],
                        ),
                      ),
                    ),
                    SizedBox(height: 40),
                    if (!userIsLoggedIn) ...[
                  ElevatedButton(
                    onPressed: () {
                      Navigator.pushNamed(context, '/login');
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Color(0xFF1C3D5A),
                      padding: EdgeInsets.symmetric(
                          horizontal: 32, vertical: 12),
                    ),
                    child: Text('تسجيل الدخول'),
                  ),
                  SizedBox(height: 16),
                  OutlinedButton(
                    onPressed: () {
                      Navigator.pushNamed(context, '/signup');
                    },
                    style: OutlinedButton.styleFrom(
                      padding: EdgeInsets.symmetric(
                          horizontal: 32, vertical: 12),
                      side: BorderSide(color: Color(0xFF1C3D5A)),
                    ),
                    child: Text(
                      'إنشاء حساب',
                      style: TextStyle(color: Color(0xFF1C3D5A)),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: _currentIndex,
          type: BottomNavigationBarType.fixed,
          onTap: (index) {
            switch (index) {
              case 0:
                if (ModalRoute.of(context)?.settings.name != '/') {
                  Navigator.pushNamed(context, '/');
                }
                break;
              case 1:
                Navigator.pushNamed(context, '/contact');
                break;
              case 2:
                Navigator.push(context, MaterialPageRoute(builder: (context) => CategoriesPage()));

                break;
              case 3:
                Navigator.pushNamed(context, '/about');
                break;
            }
            setState(() {
              _currentIndex = index;
            });
          },
          backgroundColor: Colors.white,
          selectedItemColor: Color(0xFF1C3D5A),
          unselectedItemColor: Colors.grey,
          items: [
            BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: 'الرئيسية',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.contact_mail),
              label: 'تواصل معنا',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.category),
              label: 'الفئات',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.info),
              label: 'من نحن',
            ),
          ],
        ),

    ));
  }
}