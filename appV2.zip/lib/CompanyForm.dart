import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart' show kIsWeb;

import 'FormIndIndividual.dart';
class CompanyForm extends StatefulWidget {
  const CompanyForm({Key? key}) : super(key: key);

  @override
  _CompanyFormState createState() => _CompanyFormState();
}

class _CompanyFormState extends State<CompanyForm> {
  final _formKey = GlobalKey<FormState>();
  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final phoneController = TextEditingController();
  final cityController = TextEditingController();
  final streetController = TextEditingController();
  final passwordController = TextEditingController();
  final confirmPasswordController = TextEditingController();
  final taxCardController = TextEditingController();
  final proofOfActivityController = TextEditingController();
  final commercialRegisterController = TextEditingController();

  File? profileImage;
  File? taxCardImage;
  File? proofOfActivityImage;
  File? commercialRegisterImage;
  Uint8List? profileImageWeb;
  Uint8List? taxCardImageWeb;
  Uint8List? proofOfActivityImageWeb;
  Uint8List? commercialRegisterImageWeb;

  bool isObscure = true;
  bool isConfirmObscure = true;
  bool isLoading = false;

  @override
  void dispose() {
    nameController.dispose();
    emailController.dispose();
    phoneController.dispose();
    cityController.dispose();
    streetController.dispose();
    passwordController.dispose();
    confirmPasswordController.dispose();
    taxCardController.dispose();
    proofOfActivityController.dispose();
    commercialRegisterController.dispose();
    super.dispose();
  }

  Future<void> _pickImage(int imageType) async {
    try {
      final pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery);
      if (pickedFile != null) {
        if (kIsWeb) {
          final bytes = await pickedFile.readAsBytes();
          setState(() {
            switch (imageType) {
              case 1: profileImageWeb = bytes; break;
              case 2: taxCardImageWeb = bytes; break;
              case 3: proofOfActivityImageWeb = bytes; break;
              case 4: commercialRegisterImageWeb = bytes; break;
            }
          });
        } else {
          setState(() {
            switch (imageType) {
              case 1: profileImage = File(pickedFile.path); break;
              case 2: taxCardImage = File(pickedFile.path); break;
              case 3: proofOfActivityImage = File(pickedFile.path); break;
              case 4: commercialRegisterImage = File(pickedFile.path); break;
            }
          });
        }
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("حدث خطأ: ${e.toString()}")),
      );
    }
  }

  Widget _buildImagePreview(int imageType) {
    String placeholderText;
    IconData icon;

    switch (imageType) {
      case 1:
        placeholderText = "صورة الملف الشخصي";
        icon = Icons.person;
        if (kIsWeb) {
          return profileImageWeb != null
              ? Image.memory(profileImageWeb!, fit: BoxFit.cover)
              : _buildPlaceholder(placeholderText, icon);
        } else {
          return profileImage != null
              ? Image.file(profileImage!, fit: BoxFit.cover)
              : _buildPlaceholder(placeholderText, icon);
        }
      case 2:
        placeholderText = "بطاقة الضريبة";
        icon = Icons.receipt;
        if (kIsWeb) {
          return taxCardImageWeb != null
              ? Image.memory(taxCardImageWeb!, fit: BoxFit.cover)
              : _buildPlaceholder(placeholderText, icon);
        } else {
          return taxCardImage != null
              ? Image.file(taxCardImage!, fit: BoxFit.cover)
              : _buildPlaceholder(placeholderText, icon);
        }
      case 3:
        placeholderText = "إثبات النشاط";
        icon = Icons.work;
        if (kIsWeb) {
          return proofOfActivityImageWeb != null
              ? Image.memory(proofOfActivityImageWeb!, fit: BoxFit.cover)
              : _buildPlaceholder(placeholderText, icon);
        } else {
          return proofOfActivityImage != null
              ? Image.file(proofOfActivityImage!, fit: BoxFit.cover)
              : _buildPlaceholder(placeholderText, icon);
        }
      case 4:
        placeholderText = "السجل التجاري";
        icon = Icons.business;
        if (kIsWeb) {
          return commercialRegisterImageWeb != null
              ? Image.memory(commercialRegisterImageWeb!, fit: BoxFit.cover)
              : _buildPlaceholder(placeholderText, icon);
        } else {
          return commercialRegisterImage != null
              ? Image.file(commercialRegisterImage!, fit: BoxFit.cover)
              : _buildPlaceholder(placeholderText, icon);
        }
      default: return Container();
    }
  }

  Widget _buildPlaceholder(String text, IconData icon) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: Colors.grey),
          Text(text, style: TextStyle(fontFamily: 'Tajawal')),
        ],
      ),
    );
  }

  Future<void> _register() async {
    if (!_formKey.currentState!.validate()) return;

    if (passwordController.text != confirmPasswordController.text) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("كلمة المرور غير متطابقة")),
      );
      return;
    }

    setState(() => isLoading = true);
    await Future.delayed(Duration(seconds: 2));
    setState(() => isLoading = false);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("تم تسجيل الشركة بنجاح!")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("تسجيل شركة", style: TextStyle(fontFamily: 'Tajawal')),
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Color(0xFF1C3D5A)),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("إنشاء حساب شركة", style: GoogleFonts.tajawal(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Color(0xFF1C3D5A),
              )),
              SizedBox(height: 20),

              // المعلومات الأساسية
              TextFormField(
                controller: nameController,
                decoration: InputDecoration(
                  labelText: "اسم الشركة",
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value!.isEmpty ? "مطلوب" : null,
              ),
              SizedBox(height: 16),

              TextFormField(
                controller: emailController,
                decoration: InputDecoration(
                  labelText: "البريد الإلكتروني",
                  border: OutlineInputBorder(),
                ),
                validator: (value) => !value!.contains("@") ? "بريد غير صالح" : null,
              ),
              SizedBox(height: 16),

              TextFormField(
                controller: phoneController,
                decoration: InputDecoration(
                  labelText: "رقم الهاتف",
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value!.isEmpty ? "مطلوب" : null,
              ),
              SizedBox(height: 16),

              // العنوان
              TextFormField(
                controller: cityController,
                decoration: InputDecoration(
                  labelText: "المدينة",
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value!.isEmpty ? "مطلوب" : null,
              ),
              SizedBox(height: 16),

              TextFormField(
                controller: streetController,
                decoration: InputDecoration(
                  labelText: "الشارع",
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value!.isEmpty ? "مطلوب" : null,
              ),
              SizedBox(height: 16),

              // صورة الملف الشخصي
              Text("شعار الشركة", style: GoogleFonts.tajawal(fontSize: 16)),
              SizedBox(height: 8),
              GestureDetector(
                onTap: () => _pickImage(1),
                child: Container(
                  height: 120,
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: _buildImagePreview(1),
                ),
              ),
              SizedBox(height: 16),

              // البطاقة الضريبية
              TextFormField(
                controller: taxCardController,
                decoration: InputDecoration(
                  labelText: "رقم البطاقة الضريبية",
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value!.isEmpty ? "مطلوب" : null,
              ),
              SizedBox(height: 16),

              Text("صورة البطاقة الضريبية", style: GoogleFonts.tajawal(fontSize: 16)),
              SizedBox(height: 8),
              GestureDetector(
                onTap: () => _pickImage(2),
                child: Container(
                  height: 120,
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: _buildImagePreview(2),
                ),
              ),
              SizedBox(height: 16),

              // إثبات النشاط
              TextFormField(
                controller: proofOfActivityController,
                decoration: InputDecoration(
                  labelText: "إثبات النشاط",
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value!.isEmpty ? "مطلوب" : null,
              ),
              SizedBox(height: 16),

              Text("صورة إثبات النشاط", style: GoogleFonts.tajawal(fontSize: 16)),
              SizedBox(height: 8),
              GestureDetector(
                onTap: () => _pickImage(3),
                child: Container(
                  height: 120,
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: _buildImagePreview(3),
                ),
              ),
              SizedBox(height: 16),

              // السجل التجاري
              TextFormField(
                controller: commercialRegisterController,
                decoration: InputDecoration(
                  labelText: "رقم السجل التجاري",
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value!.isEmpty ? "مطلوب" : null,
              ),
              SizedBox(height: 16),

              Text("صورة السجل التجاري", style: GoogleFonts.tajawal(fontSize: 16)),
              SizedBox(height: 8),
              GestureDetector(
                onTap: () => _pickImage(4),
                child: Container(
                  height: 120,
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: _buildImagePreview(4),
                ),
              ),
              SizedBox(height: 16),

              // كلمة المرور
              TextFormField(
                controller: passwordController,
                obscureText: isObscure,
                decoration: InputDecoration(
                  labelText: "كلمة المرور",
                  border: OutlineInputBorder(),
                  suffixIcon: IconButton(
                    icon: Icon(isObscure ? Icons.visibility_off : Icons.visibility),
                    onPressed: () => setState(() => isObscure = !isObscure),
                  ),
                ),
                validator: (value) => value!.length < 6 ? "6 أحرف على الأقل" : null,
              ),
              SizedBox(height: 16),

              TextFormField(
                controller: confirmPasswordController,
                obscureText: isConfirmObscure,
                decoration: InputDecoration(
                  labelText: "تأكيد كلمة المرور",
                  border: OutlineInputBorder(),
                  suffixIcon: IconButton(
                    icon: Icon(isConfirmObscure ? Icons.visibility_off : Icons.visibility),
                    onPressed: () => setState(() => isConfirmObscure = !isConfirmObscure),
                  ),
                ),
              ),
              SizedBox(height: 24),

              // زر التسجيل
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: isLoading ? null : _register,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF1C3D5A),
                    padding: EdgeInsets.symmetric(vertical: 16),
                  ),
                  child: isLoading
                      ? CircularProgressIndicator(color: Colors.white)
                      : Text("تسجيل الشركة", style: GoogleFonts.tajawal(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  )),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// صفحة اختيار نوع الحساب
class AccountTypePage extends StatelessWidget {
  const AccountTypePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("اختر نوع الحساب", style: TextStyle(fontFamily: 'Tajawal')),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => IndividualForm()));
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFF1C3D5A),
                padding: EdgeInsets.symmetric(horizontal: 40, vertical: 20),
              ),
              child: Text("تسجيل فرد", style: GoogleFonts.tajawal(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              )),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => CompanyForm()));
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFF1C3D5A),
                padding: EdgeInsets.symmetric(horizontal: 40, vertical: 20),
              ),
              child: Text("تسجيل شركة", style: GoogleFonts.tajawal(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              )),
            ),
          ],
        ),
      ),
    );
  }
}