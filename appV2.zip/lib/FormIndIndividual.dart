import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart' show kIsWeb;

// نموذج تسجيل الفرد
class IndividualForm extends StatefulWidget {
  const IndividualForm({Key? key}) : super(key: key);

  @override
  _IndividualFormState createState() => _IndividualFormState();
}

class _IndividualFormState extends State<IndividualForm> {
  final _formKey = GlobalKey<FormState>();
  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final phoneController = TextEditingController();
  final cityController = TextEditingController();
  final streetController = TextEditingController();
  final passwordController = TextEditingController();
  final confirmPasswordController = TextEditingController();

  File? profileImage;
  Uint8List? profileImageWeb;

  bool isObscure = true;
  bool isConfirmObscure = true;
  bool isLoading = false;

  @override
  void dispose() {
    nameController.dispose();
    emailController.dispose();
    phoneController.dispose();
    cityController.dispose();
    streetController.dispose();
    passwordController.dispose();
    confirmPasswordController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    try {
      final pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery);
      if (pickedFile != null) {
        if (kIsWeb) {
          final bytes = await pickedFile.readAsBytes();
          setState(() => profileImageWeb = bytes);
        } else {
          setState(() => profileImage = File(pickedFile.path));
        }
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("حدث خطأ: ${e.toString()}")),
      );
    }
  }

  Widget _buildImagePreview() {
    if (kIsWeb) {
      return profileImageWeb != null
          ? Image.memory(profileImageWeb!, fit: BoxFit.cover)
          : _buildPlaceholder();
    } else {
      return profileImage != null
          ? Image.file(profileImage!, fit: BoxFit.cover)
          : _buildPlaceholder();
    }
  }

  Widget _buildPlaceholder() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.person, color: Colors.grey),
          Text("صورة الملف الشخصي", style: TextStyle(fontFamily: 'Tajawal')),
        ],
      ),
    );
  }

  Future<void> _register() async {
    if (!_formKey.currentState!.validate()) return;

    if (passwordController.text != confirmPasswordController.text) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("كلمة المرور غير متطابقة")),
      );
      return;
    }

    setState(() => isLoading = true);
    await Future.delayed(Duration(seconds: 2));
    setState(() => isLoading = false);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("تم التسجيل بنجاح!")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("تسجيل فرد", style: TextStyle(fontFamily: 'Tajawal')),
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Color(0xFF1C3D5A)),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("إنشاء حساب فردي", style: GoogleFonts.tajawal(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Color(0xFF1C3D5A),
              )),
              SizedBox(height: 20),

              // المعلومات الأساسية
              TextFormField(
                controller: nameController,
                decoration: InputDecoration(
                  labelText: "الاسم الكامل",
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value!.isEmpty ? "مطلوب" : null,
              ),
              SizedBox(height: 16),

              TextFormField(
                controller: emailController,
                decoration: InputDecoration(
                  labelText: "البريد الإلكتروني",
                  border: OutlineInputBorder(),
                ),
                validator: (value) => !value!.contains("@") ? "بريد غير صالح" : null,
              ),
              SizedBox(height: 16),

              TextFormField(
                controller: phoneController,
                decoration: InputDecoration(
                  labelText: "رقم الهاتف",
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value!.isEmpty ? "مطلوب" : null,
              ),
              SizedBox(height: 16),

              // العنوان
              TextFormField(
                controller: cityController,
                decoration: InputDecoration(
                  labelText: "المدينة",
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value!.isEmpty ? "مطلوب" : null,
              ),
              SizedBox(height: 16),

              TextFormField(
                controller: streetController,
                decoration: InputDecoration(
                  labelText: "الشارع",
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value!.isEmpty ? "مطلوب" : null,
              ),
              SizedBox(height: 16),

              // صورة الملف الشخصي
              Text("صورة الملف الشخصي", style: GoogleFonts.tajawal(fontSize: 16)),
              SizedBox(height: 8),
              GestureDetector(
                onTap: _pickImage,
                child: Container(
                  height: 120,
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: _buildImagePreview(),
                ),
              ),
              SizedBox(height: 16),

              // كلمة المرور
              TextFormField(
                controller: passwordController,
                obscureText: isObscure,
                decoration: InputDecoration(
                  labelText: "كلمة المرور",
                  border: OutlineInputBorder(),
                  suffixIcon: IconButton(
                    icon: Icon(isObscure ? Icons.visibility_off : Icons.visibility),
                    onPressed: () => setState(() => isObscure = !isObscure),
                  ),
                ),
                validator: (value) => value!.length < 6 ? "6 أحرف على الأقل" : null,
              ),
              SizedBox(height: 16),

              TextFormField(
                controller: confirmPasswordController,
                obscureText: isConfirmObscure,
                decoration: InputDecoration(
                  labelText: "تأكيد كلمة المرور",
                  border: OutlineInputBorder(),
                  suffixIcon: IconButton(
                    icon: Icon(isConfirmObscure ? Icons.visibility_off : Icons.visibility),
                    onPressed: () => setState(() => isConfirmObscure = !isConfirmObscure),
                  ),
                ),
              ),
              SizedBox(height: 24),

              // زر التسجيل
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: isLoading ? null : _register,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF1C3D5A),
                    padding: EdgeInsets.symmetric(vertical: 16),
                  ),
                  child: isLoading
                      ? CircularProgressIndicator(color: Colors.white)
                      : Text("تسجيل", style: GoogleFonts.tajawal(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  )),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// نموذج تسجيل الشركة


// يمكنك استخدام هذا في main.dart
/*
void main() {
  runApp(MaterialApp(
    home: AccountTypePage(),
    theme: ThemeData(
      fontFamily: 'Tajawal',
    ),
  ));
}
*/